'''
Numerical differentiation.
Using finite difference methods to find the first order derivative
of a function at a point.
'''

import numpy as np

#Define the function using the lambda function
def fordiff(func, x, step = 0.01):
	deriv = (func((x + step)) - func(x)) / step
	return deriv

def bacdiff(func, x, step = 0.01):
	deriv = (func(x) - func(x - step)) / step
	return deriv

def cendiff(func, x, step = 0.01):
	deriv = (func((x + step)) - func((x -step))) / (2*step)
	return deriv

def centdiff_func(func, step, n):
	return ((func[n - 1] - func[n + 1])/ (2*step))

def centdiff_point(y1, y_1, step):
	return ((y1 - y_1)/ (2*step))
'''
def FDM(func, n, step = 0.01):
'''
	
