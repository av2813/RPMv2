import numpy as np
import lattice_builder_new as lb
import matplotlib.pyplot as plt
import time as tm
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import time as tm
import os
import linecache as lc
import math
from scipy import stats
import ast
import saving_opening as so


plt.rc('text', usetex=True)
plt.rc('font', family='serif', size = 22)


target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/Boundary"

omega_list = []
iterations_list = []
step_list = []
tolerance_list = []
boundary_list = []
potential_section_x =[]
x_position = []


for name in os.listdir(target_dir):
	if name.endswith(".txt"):
		area_object, area_potential, method, ordering, tolerance, omega, iterations, step, boundary = so.read(name, target_dir)
		boundary_list.append(boundary[0])
		step_list.append(step)
		K = lb.Shape(step, area_object, area_potential)
		ob, pot = K.cross_section('x', (boundary[1]/2))
		pot_side = []
		for o, p in zip(ob, pot):
			if o != 1:
				pot_side.append(p)
			else: 
				break
		pot_side.reverse()
		potential_section_x.append(pot_side)
		x_position.append(np.linspace(step, boundary[0]/2, num = len(pot_side)))
		

def linear(x, m = -100, c = 10):
	ans = []
	for i in range(x.size):
		ans.append((m*x[i] +c))
	return np.array(ans)

def log_func(x, A= -2.5, C = 1,D= 10.):
	ans = []
	for i in range(x.size):
		if (x[i] + C) <= 0:
			ans.append(100.)
		else:
			ans.append((A * math.log((x[i] + C))+D))
tube = 0.

def superposition(x, m = -100., c = 10., A = -5., B = 1., C = 10.):
	ans = []
	for i in range(x.size):
		if (x[i] + B) < 0.:
			ans.append(100.)
		else:
			ans.append((m*x[i] +c)  + (A * math.log((x[i] + B))+C))
		
	return ans

import scipy.optimize as scopt

ratio = []
alpha_list = []
beta_list = []
for x, pot in zip(x_position, potential_section_x):
	tube = boundary_list[i]
	popt, pcov = scopt.curve_fit(superposition, np.array(x), np.array(pot), maxfev = 100000)
	alpha_list.append(abs(popt[0]))
	beta_list.append(abs(popt[2]))
	ratio.append(abs(popt[2]/popt[0]))
	
plt.plot(boundary_list, alpha_list, 'r.', label = 'Linear')
plt.plot(boundary_list, beta_list, 'b.', label = 'Logarithmic')

plt.xlabel('Width of the tube (cm)')
plt.ylabel('Factor')
plt.legend(loc=1)

plt.show()


plt.show()
