PROJECT B2 - EDM Experiment Version 1.0 16/11/2015


FILES
-------------------
Num_diff.py
gradient.py
graphing_x_axis.py
interpolation.py
saving_opening.py
test.py
test_new.py
test_boundary.py
test_boundary_read.py
test_simple_new.py
test_updatestep.py

GENERAL USAGE NOTES
-------------------

Num_diff is a collection of functions tha perform numericla differentiation on
both list and functions.

gradient module produces all the electric field graphs in the report. It takes
take a previously solved potential and converts it to an electric field. Also 
contains the function for searching through the electric field and finding the
largest homogeneous area

graphing_x_axis graphs testing area for graphing the potential of a system 
along an axis.

interpolation is a contains the functions for bilinear and linear interpolation

saving_opening saves the grid and relvant parameters to a text file and saves
a heatmap as a image file. When saving all the parameters have to specified as 
variables in the function along with the arrays that describe the objects and 
the potential. The images are saved as .png files under the same name. While 
opening only takes the name file and directory in which is tis located and 
returns all of the parameters along with the arrays.

test deals with solving and generating the potentials for the EDM experiment.

test_boundary iterates through a range of boundaries and saves the information
and heatmap to file.

test_boundary_read takes the boundary results and exacts the relant information
in order to graph the solve the system in terms of a linear and logarithmic
solution

test_simple_new is a functional file for displaying and saving the results for
a the simple configuration

test_updatestep takes are already solved potential array and bilinearly
interpolates down to half the gird spacing then saves the updated information
using saving_opening

