import numpy as np
import lattice_builder_new as lb
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import saving_opening as so
import math


target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/Simple"


#Saves the solutions to the system for a range of steps
tolerance = 10e-9
ordering = "redblack"
method = "SOR"
step_range_line = np.linspace(0.05, 0.01, 10)
boundary = [6., 6.]
initial_cond = 'zero'

for step in step_range_line:
	K = lb.Shape(step)
	K.boundary(dim = boundary, boundary_pot = 0.)
	K.rectangle(dim = [2., 2.], pos = [3., 3.], potential = 10.)
	area_object, area_potential = K.areas()

	A = lb.Pictorial(area_object, area_potential)
	omega = A.optimal_omega()
	while A.convergence(tolerance) == False:
		A.redblack(w = omega)
	iterations = A.counter()

	plt.clf()
	fig, ax = plt.subplots(1,1)
	plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
	plt.colorbar()

	name = "Simple_{0}_{1}_{2}_{3}".format(str(step), str(omega), str(tolerance), str(boundary))
	so.write(name, target_dir, fig, area_object, area_potential, method, ordering, tolerance, omega, iterations, step, boundary, initial_cond)

#Saves the solutions to the system for a range of tolerances
tolerance_range = np.logspace(-14, -5, 30)
ordering = "redblack"
method = "SOR"
step = 0.05
boundary = [6., 6.]
initial_cond = 'zero'

for tolerance in tolerance_range:
	print tolerance
	K = lb.Shape(step)
	K.boundary(dim = boundary, boundary_pot = 0.)
	K.rectangle(dim = [2., 2.], pos = [3., 3.], potential = 10.)
	area_object, area_potential = K.areas()

	A = lb.Pictorial(step,area_object, area_potential)
	omega = A.optimal_omega()
	while A.convergence(tolerance) == False:
		A.redblack(w = omega)
	iterations = A.counter()

	plt.clf()
	fig, ax = plt.subplots(1,1)
	plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
	plt.colorbar()

	name = "Simple_{0}_{1}_{2}_{3}".format(str(step), str(omega), str(tolerance), str(boundary))
	so.write(name, target_dir, fig, area_object, area_potential, method, ordering, tolerance, omega, iterations, step, boundary, initial_cond)




