'''
Will go through a directory and use bilinear interpolation to get an approx
for the solution at half the step size. It will then use this as its initial
condition.
'''

import lattice_builder_new as lb
import matplotlib.pyplot as plt
import os
import saving_opening as so

target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/Simple"

omega_list = []
iterations_list = []
step_list = []
tolerance_list = []


for name in os.listdir(target_dir):
	if name.endswith(".txt"):
		area_object_new, area_potential_new, method, ordering, tolerance, omega, iterations, step, boundary = so.read(name, target_dir)
		K = lb.Shape(step, area_object = area_object_new, area_potential = area_potential_new)
		print step
		step = K.update_step(2)
		area_object_new, area_potential_new = K.areas()
		A = lb.Pictorial(step, area_object_new, area_potential_new)	
		initial_conditions = "bilinear_factor2"
		omega = A.optimal_omega()
		while A.convergence(tolerance) == False:	
			A.redblack(w = omega)
		iterations = A.counter()
		plt.clf()
		fig, ax = plt.subplots(1,1)
		plt.imshow(area_potential_new, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
		plt.colorbar()

		name_new = "Simple_{0}_{1}_{2}_{3}".format(str(step), str(omega), str(tolerance), str(boundary))
		target_dir2 = target_dir + "/bilinear"
		so.write(name_new, target_dir2, fig, area_object_new, area_potential_new, method, ordering, tolerance, omega, iterations, step, boundary, initial_conditions)
		


