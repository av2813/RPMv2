import numpy as np
import lattice_builder_new as lb
import matplotlib.pyplot as plt
import time as tm
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import saving_opening as so


start_time = tm.time()
step = 1.
K = lb.Shape(step)
boundary = [290., 290.]		#note if you change the 

K.boundary(dim = boundary)
small_plate = [20.,10.]
big_plate = [200.,10.]
small_pot = 2.
big_pot = 8.
potential = [small_pot, big_pot]
K.rectangle(dim = small_plate, pos = [boundary[0]/2.-120., boundary[1]/2.-10.], potential = -small_pot)
K.rectangle(dim = small_plate, pos = [boundary[0]/2.-120., boundary[1]/2.+10.], potential = small_pot)
K.rectangle(dim = small_plate, pos = [boundary[0]/2.-120., boundary[1]/2.-10.], potential = -small_pot)
K.rectangle(dim = small_plate, pos = [boundary[0]/2.-120., boundary[1]/2.+10.], potential = small_pot)
K.rectangle(dim = big_plate, pos = [boundary[0]/2., boundary[1]/2.-10.], potential = -big_pot)
K.rectangle(dim = big_plate, pos = [boundary[0]/2., boundary[1]/2.+10.], potential = big_pot)


ordering = 'redblack'
method = "SOR"
target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/EDM/test"

area_object, area_potential = K.areas()
A = lb.Pictorial(step, area_object, area_potential)
omega = A.optimal_omega()
tolorence = 10e-12
i = 0
while A.convergence(tolorence = tolorence) == False:
	A.redblack(w = omega)
print A.counter()

iterations = A.counter()
initial_cond = 'zero'
plt.clf()
fig, ax = plt.subplots(1,1)
plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
plt.colorbar()
print step
so.write('edm', target_dir, fig, area_object, area_potential, method, ordering, tolorence, omega, iterations, step, boundary, initial_cond)
'''
Depends how long you want your computer to run for 
K = lb.Shape(step, area_object, area_potential)
step = K.update_step(factor = 2)
area_object, area_potential = K.areas()
A = lb.Pictorial(step,area_object, area_potential)
omega = A.optimal_omega()
print step
while A.convergence(tolorence = tolorence) == False:
	A.redblack(w = omega)

iterations = A.counter()
initial_conditions = 'bilinear_factor2'

plt.clf()
fig, ax = plt.subplots(1,1)
plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
plt.colorbar()
so.write('edm', target_dir, fig, area_object, area_potential, method, ordering, tolorence, omega, iterations, step, boundary, initial_cond)


K = lb.Shape(step, area_object, area_potential)
step = K.update_step(factor = 2)
area_object, area_potential = K.areas()
A = lb.Pictorial(step, area_object, area_potential)
omega = A.optimal_omega()
print step

while A.convergence(tolorence = tolorence) == False:
	A.redblack(w = omega)

iterations = A.counter()
initial_conditions = 'bilinear_factor2'

plt.clf()
fig, ax = plt.subplots(1,1)
plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
plt.colorbar()
so.write('edm', target_dir, fig, area_object, area_potential, method, ordering, tolorence, omega, iterations, step, boundary, initial_cond)

K = lb.Shape(step, area_object, area_potential)
step = K.update_step(factor = 2)
area_object, area_potential = K.areas()
A = lb.Pictorial(step,area_object, area_potential)
omega = A.optimal_omega()
print step

while A.convergence(tolorence = 0.001*tolorence) == False:
	A.redblack(w = omega)

iterations = A.counter()
initial_conditions = 'bilinear_factor2'

plt.clf()
fig, ax = plt.subplots(1,1)
plt.imshow(area_potential, aspect = 'auto', extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
plt.colorbar()
so.write('edm', target_dir, fig, area_object, area_potential, method, ordering, tolorence, omega, iterations, step, boundary, initial_cond)
'''