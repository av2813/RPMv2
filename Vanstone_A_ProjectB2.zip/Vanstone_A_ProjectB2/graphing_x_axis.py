import numpy as np
import lattice_builder_new as lb
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import os
import linecache as lc
import math
from scipy import stats
import matplotlib.pyplot as plt
import ast
import saving_opening as so
from decimal import Decimal






target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/Boundary"

omega_list = []
iterations_list = []
step_list = []
tolerance_list = []
pot_side = []

plt.close()
fig1, ax1 = plt.subplots(1, 1)
#for name in os.listdir(target_dir):
name = 'Simple_0.5_1.96952124874_0.0001_[102.0, 102.0].txt'
if name.endswith(".txt"):
	area_object, area_potential, method, ordering, tolerance, omega, iterations, step, boundary = so.read(name, target_dir)
	#if step == 0.01 or step == 0.05 or step == 0.1 or abs(step-0.3666) < 0.01:
	K = lb.Shape(step, area_object = area_object, area_potential = area_potential)
	ob_x, pot_x = K.cross_section(dir = 'x', pos = boundary[1]/2.)
	x = np.linspace(-boundary[0]/2, boundary[0]/2, len(pot_x), endpoint = True)
	for o, p in zip(ob_x, pot_x):
		if o != 1:
			pot_side.append(p)
		else: 
			break
	ax1.plot(x, pot_x, '.', label = "step: {0}".format(str(round(step,2))), alpha = 0.7)
		


plt.ylabel('Potential (V)')
plt.xlabel('x (cm)')
ax1.set_ylim([0.,12.])

plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)


x_2 = np.linspace(step, boundary[0]/2. - 1., len(pot_side))
fig2, ax2 = plt.subplots(1,1)
pot_side.reverse()
print len(pot_side)
ax2.plot(x_2, pot_side, '.', label = "Simulated potential curve")
plt.ylabel('Potential (V)')
plt.xlabel('s (cm)')


######################################
# Setting up test data
import numpy as np
from scipy.optimize import leastsq
import matplotlib.pyplot as plt


def linear(x, m = -100, c = 10):
	ans = []
	for i in range(x.size):
		ans.append((m*x[i] +c))
	return np.array(ans)

def log_func(x, A= -2.5, C = 1,D= 10.):
	ans = []
	for i in range(x.size):
		if (x[i] + C) <= 0:
			ans.append(100.)
		else:
			ans.append((A * math.log((x[i] + C))+D))

	return np.array(ans)
	print np.array(ans)

m, c = [20., 0.1]
p = [m, c]
pot_init = linear(x_2, m, c)

import scipy.optimize as scopt

popt, pcov = scopt.curve_fit(log_func, x_2, pot_side)
perr = np.sqrt(np.diag(pcov))
print popt
print perr







pot_est = log_func(x_2, popt[0], popt[1], popt[2])
slope, intercept, r_value, p_value, std_err = stats.linregress(pot_side,pot_est)
print r_value**2
pot_theory = log_func(x_2, -2.5, 1., 10.)
plt.plot(x_2, pot_theory, label = "Theoretical function")
plt.plot(x_2, pot_est, label = "Best fit function")
plt.ylabel('Potential (V)')
plt.xlabel('s (cm)')
plt.rc('text', usetex=True)
plt.rc('font', family='serif', size = 14)
plt.legend(loc=1)


'''
mean1, mean2 = 0, -2
std1, std2 = 0.5, 1 

x = np.linspace(-20, 20, 500)


######################################
# Solving
m, dm, sd1, sd2 = [5, 10, 1, 1]
p = [m, dm, sd1, sd2] # Initial guesses for leastsq
y_init = norm(x, m, sd1) + norm(x, m + dm, sd2) # For final comparison plot



def res(p, y, x):
  m, dm, sd1, sd2 = p
  m1 = m
  m2 = m1 + dm
  y_fit = norm(x, m1, sd1) + norm(x, m2, sd2)
  err = y - y_fit
  return err

plsq = leastsq(res, p, args = (y_real, x))

y_est = norm(x, plsq[0][0], plsq[0][2]) + norm(x, plsq[0][0] + plsq[0][1], plsq[0][3])
'''
plt.show()