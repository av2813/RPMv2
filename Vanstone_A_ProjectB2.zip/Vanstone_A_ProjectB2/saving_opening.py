import numpy as np
import matplotlib.pyplot as plt
import os
import linecache as lc
import ast


def write(description, target_dir, fig, area_object, area_potential, method, ordering,
			tolerance, omega, iterations, step, boundary, 
			intitial_cond):
	'''
	Will save a text file and image file (fig) to a directory (target_dir) with
	the file name description.
	Save all the relevant parameter to the second line of the text file
	Saves the area_potential to the third line of the text file
	Saves the area_object to the fourth line of the text file
	Saves the intitial_cond to the last line of the text file
	'''
	testing = method, ordering, tolerance, omega, iterations, step, boundary
	name = description + "_{1}_{1}_{2}_{3}".format(str(step), str(omega), str(tolerance), str(boundary))
	file_name = os.path.join(target_dir, name + ".txt")
	pic_name = os.path.join(target_dir, name + ".png")
	fig.savefig(pic_name, bbox_inches='tight')
	plt.close(fig)
	with open(file_name, "w") as data:
		data.write('Method Ordering Tolerance Omega Iterations step Boundary Potential\n')
		data.write(str(testing).strip(',')+'\n')
		data.write(str(area_potential.tolist())+'\n')
		data.write(str(area_object.tolist())+'\n')
		data.write(intitial_cond)
		data.close()


def read(name, target_dir):
	'''
	Given the name of the file and the directory (traget_dir) where the file is 
	located will return the area_object and the area_potential along with all the 
	parameters that were saved using the write function. 
	The file has to be a text file (.txt)
	'''
	file_name = os.path.join(target_dir, name)
	with open(file_name, "r") as data:
		x = data.readlines()
		data.close()
	area_potential = x[2]
	area_object = x[3]
	area_potential_new = np.array(ast.literal_eval(area_potential))
	area_object_new = np.array(ast.literal_eval(area_object))
	var = x[1].split()
	method = var[0].replace(",", "").strip("''")
	ordering = var[1].replace(",", "").replace("'", "").replace("(", "")
	tolerance = float(var[2].replace(",", ""))
	omega = float(var[3].replace(",", ""))
	iterations = float(var[4].replace(",", ""))
	step = float(var[5].replace(",",""))
	boundary_x = float(var[6].replace(",", "").replace("[", ""))
	boundary_y = float(var[7].replace(",", "").replace("]", "").replace(")", ""))
	boundary = [boundary_x, boundary_y]
	return area_object_new, area_potential_new, method, ordering, tolerance, omega, iterations, step, boundary