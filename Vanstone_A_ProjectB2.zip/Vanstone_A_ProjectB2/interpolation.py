


def linear_interpol(point, point_prev = [], point_next=[]):
	'''
	The value of the function and the position of the function must be 
	given for the point_next and the point_prev in the form of a list of 2
	values. eg. point_prev[value of position, value of function]
	While the point is just given as a posiion that is between the positions
	of the other 2 points.
	'''
	if point > (point_next[0] or point < point_prev[0]):
		raise Exception("The position of the point is not inbetween the previous point the next point")
	if len(point_next) != 2 or len(point_prev) != 2:
		raise Exception("The point is not defined for both the point and the value of the function")
	return (((point_next[0] - point)*point_next[1] + (point - point_prev[0])*point_next[1])
			/ (point_next[0] - point_prev[0])) 

def bilinear_interpol(point, point1, point2, point3, point4):
	F1 = linear_interpol(point[1], [point1[1],point1[2]], [point2[1],point2[2]])
	F2 = linear_interpol(point[1], [point3[1],point3[2]], [point4[1],point4[2]])
	return linear_interpol(point[0], [point1[0], F1], [point3[0], F2])
				