import numpy as np
import Num_diff as nd
import saving_opening as so
import matplotlib.pylab as plt
import os

plt.rc('text', usetex=True)
plt.rc('font', family='serif', size = 22)

def gradient(array, step):
	'''
	returns the partial derviative of the system in the x and y direction
	using central a central difference method
	the array parameter should be a 2D array
	the step should be the grid spacing (it is assumed that it is the same in
		both directions)
	'''
	Lx, Ly = np.shape(array)
	grad_x = np.empty((Lx, Ly), dtype = float)
	grad_y = np.empty((Lx, Ly), dtype = float)
	i = 0
	while i < (Lx-1):
		j = 0

		while j < (Ly-1):
			dx = nd.centdiff_point(array[i, j+1], array[i, j - 1], step)
			dy = nd.centdiff_point(array[i+1, j], array[i - 1, j], step)
			grad_x[i, j] = dx
			grad_y[i, j] = dy
			j+=1

		i+=1

	return grad_x, grad_y

def search(array, precision, start_point, step, radius):
	'''
	Searches through an array within the radius of the starting point 
	(givein as a list) for all points that are within the precision times
	value of the array at the stating point. 
	The step parameter is the grid sapcing 
	'''
	print [int(start_point[0]/step), int(start_point[1]/step)]
	start_E = array[int(start_point[0]/step), int(start_point[1]/step)]
	Lx, Ly = np.shape(array)
	B = np.zeros((Lx, Ly), dtype = float)
	i = start_point[0] - radius
	area = 0
	i = start_point[0]-0.5*radius
	while i < (0.5*radius+start_point[0]):
		j = start_point[1]-0.5*radius
		n = i/step
		while j < (0.5*radius+start_point[1]):
			m = j/step
			if abs((array[n, m]-start_E)) <= abs(start_E)*precision:
				area += step**2
				B[n, m] =1000
			j += step
		i += step
	return B, area

def cross_section(array,step, dir, pos):
	'''
	The function returns the section of the array at a specified position pos
	either the "x" or the "y" direction.
	the array parameter is a 2D array
	The step parameter is the grid spacing
	The dir is given as a string in the form "x" or "y" to which axis section
	will be returned
	The pos is given as a float along the boundary of the axis. This is
	converted into an integer in order to index the array.
	'''
	index = int(pos/step)
	if dir == 'x':
		return array[index,:]
	if dir == 'y':
		return array[:,index]

#The directory and and the name of the file you want to work with
target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/EDM/test/bilinear"
name = 'Simple_0.35_1.99243120655_1e-11_[290.0, 290.0]_1.99243120655_1.99243120655_1e-11_[290.0, 290.0].txt'



#Takes the potential of an already solved problem and displays the gradient as vector field
area_object_new, area_potential_new, method, ordering, tolerance, omega, iterations, step, boundary = so.read(name, target_dir)
dx, dy = gradient(area_potential_new, step)
skip = (slice(None, None, 3), slice(None, None, 3))
fig3, ax3 = plt.subplots(1,1)
ax3.quiver(-dx[skip], -dy[skip], area_potential_new[skip])
plt.xlabel("x (mm)")
plt.ylabel("y (mm)")
ax3.set(aspect=1)



mag_E = []
for gradx, grady in zip(dx, dy):
	mag_E.append(1000*((gradx)**2 + (grady)**2)**0.5)  	#multiplied by 1000 to convert from millimetres to metres


#displays the electric field strength as a heatmap
fig1, ax1 = plt.subplots(1,1)
plt.imshow(mag_E, extent = (-boundary[0]/2,boundary[0]/2,-boundary[1]/2,boundary[1]/2), interpolation='none')
cbar = plt.colorbar()
plt.xlabel('x (mm)')
plt.ylabel('y (mm)')
cbar.set_label(r'Electric field strength ($kVm^{-1}$)', rotation=90)
name = 'Electric_field_05'


#displays the electric field strength along the central line of the graph
dx_sect = cross_section(dx, step, 'y', boundary[0]/2)
dy_sect = cross_section(dy, step, 'y', boundary[0]/2)

mag_E_sect = []
for gradx, grady in zip(dx_sect, dy_sect):
	mag_E_sect.append(1000*((gradx)**2 + (grady)**2)**0.5)		#multiplied by 1000 to convert from millimetres to metres

y = np.linspace(-boundary[0]/2, boundary[0]/2, len(mag_E_sect))
fig4, ax4 = plt.subplots(1,1)
plt.plot(y, mag_E_sect, '-')
plt.xlabel("y (mm)")
plt.ylabel(r'Electric Field $(kVm^{-1})$')

#find the homogeneous area based on the central point of the plates
for x in np.logspace(-7, -3, 5):
	homogeneous, area = search(np.array(mag_E), x, [boundary[0]/2., boundary[1]/2.], step, 50.) # in order to find the region homogeneous 
fig2, ax2 = plt.subplots(1,1)																	# for the smaller plates add\subtract 120. to the 
plt.imshow(homogeneous)																			#first term in the specifying the start_point

plt.show()
