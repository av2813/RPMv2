import numpy as np
import time as tm
import matplotlib.pyplot as plt
import random as rand
from matplotlib import cm
from multiprocessing import Pool
import interpolation as inp
import math




class Shape:

	def __init__(self, step, area_object = None, area_potential = None):
		self.step = step
		self.area_object = area_object
		self.area_potential = area_potential

	def areas(self):
		'''
		Returns the area_object and area_potential
		'''
		return self.area_object, self.area_potential

	def step_size(self):
		'''
		Returns the grid spacing
		'''
		return self.step
	
	def boundary(self, dim = [6., 6.], boundary_pot = 0.):
		'''
		The dim parameter gives the x and y length of the boundaries of the system respectively
		boundary_pot is the potential at which the boundary will be fixed.
		'''
		#B1 = np.zeros((int(dim[0]/self.step), int(dim[1]/self.step)), dtype = float)

		Lx = int(dim[0]/self.step)
		Ly = int(dim[1]/self.step)
		B1 = []
		B2 = []
		i = 0
		while i < Lx:
			j = 0
			b2 = []
			b1 = []
			while j < Ly:
				if i == 0:
					b2.append(-1)
					b1.append(boundary_pot)
				elif i == (Lx-1):
					b2.append(-1)
					b1.append(boundary_pot)
				elif j == 0:
					b2.append(-1)
					b1.append(boundary_pot)
				elif j == (Ly - 1):
					b2.append(-1)
					b1.append(boundary_pot)
				else:
					b2.append(0)
					b1.append(0.)
				j += 1
			B2.append(b2)
			B1.append(b1)
			i += 1
		self.area_object = np.array(B2)
		self.area_potential = np.array(B1)


	def rectangle(self, dim = [2., 2.], pos = [3., 3.], potential = 10.):
		'''
		The dim parameter gives the x and y dimensions of the object
		The pos parameter gives the position of the object within the 
		bound area. The object and its dimensions must be within the 
		bound area.
		'''
		if self.area_object == None:
			raise Exception("The boundary is not defined")
		i = pos[0]-0.5*dim[0]
		while i < (0.5*dim[0]+pos[0]):
			j = pos[1]-0.5*dim[1]
			n = i/self.step
			while j < (0.5*dim[1]+pos[1]):
				m = j/self.step
				self.area_object[n, m] = 1
				self.area_potential[n, m] = potential
				j += self.step
			i += self.step

	def random_initial(self, potential):
		'''
		The areas in the grid that do not have an object or a boundary are 
		set to be a random number between 0 and the potential.
		'''
		Lx, Ly = np.shape(self.area_object)
		i = 0
		while i < Lx:
			j = 0.
			while j < Ly:
				if self.area_object[i, j] == 0:
					self.area_potential[i,j] = potential*rand.random()
				j+=1
			i+=1

	def reducedstep_initial(self, factor):
		'''
		Using the update step method in the Pictorial class step size is divided
		by the factor but the initial state of the system is now close to the final solution
		thus decreasing the number of iterations till convergence.
		'''
		A = Pictorial(slef.step, self.area_object, self.area_potential)
		omega = A.optimal_omega()
		while A.convergence(1e-5) == False:		#the convergence 
			A.redblack(method = 'redblack', w = omega)
		self.step = A.update_step(self.step, factor)

	def circle(self, radius = 2., pos = [6.,6.], potential = 10.):
		'''
		Creates a circular object.
		the radius parameter specifies the radius of the circle
		the pos parameter specifies the position of the parameter on the grid  
		'''
		if self.area_object == None:
			raise Exception("The boundary is not defined")
		i = pos[0] - radius
		while i < pos[0] + radius:
			j = pos[1] - radius
			n = i/self.step
			while j < pos[1] + radius:
				m = j/self.step
				if (((i-pos[0])**2+(j-pos[1])**2)**0.5) < radius:
					self.area_object[n, m] = 1
					self.area_potential[n, m] = potential
				j+=self.step
			i+=self.step

	def update_step(self, factor):
		'''
		The factor represents what the time step is being updated by. The 
		old step is being divided by the factor. 
		'''
		self.step = self.step/factor
		Lx, Ly = np.shape(self.area_object)
		i = 0
		B1 = np.zeros((Lx*factor, Ly*factor), dtype = float)		#self.area_potential.tolist()
		B2 = np.empty((Lx*factor, Ly*factor), dtype = float)
		B2.fill(False)
		Lxb, Lyb = np.shape(B2)
		B1.tolist()
		B2.tolist()
		while i < (Lx-1):
			j = 0
			while j < (Ly-1):
				if i == 0:
					l = 0
					while l < factor:
						B2[0][factor*j+l] = -1
						B1[0][factor*j+l] = 0.
						l+=1
				elif i == (Lx-1):
					l = 0
					while l < factor:
						B2[Lxb-1][factor*j+l] = -1
						B1[Lxb-1][factor*j+l] = 0.
						l+=1
				elif j == 0:
					l = -factor
					while l < 2*factor:
						B2[factor*i+l][0] = -1
						B1[factor*i+l][0] = 0.
						l+=1
				elif j == (Ly-1):
					l = -factor
					while l < 2*factor:
						B2[factor*i+l][Lyb-1] = -1
						B1[factor*i +l][Lyb-1] = 0.
						l+=1
				else:
					if self.area_object[i][j] == 0:
						B1[factor*i][factor*j] = self.area_potential[i][j]
					else:
						n = 0
						while n < factor:
							m = 0
							while m < factor:
								B2[factor*i + n][factor*j + m] = 1
								B1[factor*i + n][factor*j + m] = self.area_potential[i][j]
								m+=1
							n+=1
				j+=1
			i+=1
		i = 0
		while i < (Lx-1):
			j = 0
			while j < (Ly-1):
				if B2[i*factor][j*factor] != 1:
					k = 1
					point1 = [i*factor, j*factor, B1[i*factor][j*factor]]
					point2 = [i*factor, (j+1)*factor-1, B1[i*factor][(j+1)*factor]]
					point3 = [(i+1)*factor, j*factor, B1[(i+1)*factor][j*factor]]
					point4 = [(i+1)*factor, (j+1)*factor, B1[(i+1)*factor][(j+1)*factor]]
					while k < factor:
						l = 1
						while l < factor:
							B1[i*factor+k][j*factor+l] = inp.bilinear_interpol([i*factor+k, j*factor+l], point1, point2, point3, point4)
							if i != 0:
								B1[i*factor][j*factor+l] = inp.linear_interpol((j*factor+l), [point1[1],point1[2]], [point2[1],point2[2]])
							if j != 0:
								B1[i*factor+k][j*factor] = inp.linear_interpol((i*factor+k), [point1[0],point1[2]], [point3[0],point3[2]])
							l+=1
						k+=1
				j+=1
			i+=1


		self.area_potential = np.array(B1)
		self.area_object = np.array(B2)
		return self.step

	def cross_section(self, dir, pos):
		'''
		The function returns the section of the array at a specified position pos
		either the "x" or the "y" direction.
		The dir is given as a string in the form "x" or "y" to which axis section
		will be returned
		The pos is given as a float along the boundary of the axis. This is
		converted into an integer in order to index the array.
		'''
		index = int(pos/self.step)
		if dir == 'x':
			return self.area_object[index,:], self.area_potential[index,:]
		if dir == 'y':
			return self.area_object[:,index], self.area_potential[:,index]

	

class Pictorial:
	def __init__(self,step, area_object, area_potential):
		self.area_object = area_object
		self.area_potential = area_potential
		self.count = 0
		self.error_frac = 1.
		self.step = step

	def SOR(self,w, u_ij, ui_j,uij, u__ij,ui__j):
		'''
		pictorial equation for the Laplace equation using SOR
		w = relaxation parameter (must be within 1<= w < 2)
		u_ij is the (i + 1, j) point on the grid
		ui_j is the (i, j + 1) point on the grid
		uij is the (i, j) point on the grid
		u_ij is the (i - 1, j) point on the grid
		u_ij is the (i, j - 1) point on the grid
		'''
		if w > 2.:
			raise Exception("The SOR method will not converge for a w greater than 2")
		return (1- w)*uij + 0.25*w*(u_ij + ui_j + u__ij + ui__j)

	def residual(self, u_ij, ui_j, uij, u__ij,ui__j):
		'''
		Returns the residual of the area at each point
		'''
		return 0.25*(u_ij + ui_j + u__ij + ui__j - 4*uij)

	def redblack(self, w = 1.8):
		'''
		The ordering with which the matrix is updated. Goes through the grid
		in a checkboard style fashion. First updating all the red points
		and then updating all the black points
		w = over relaxation parameter (must be within 1<= w < 2)
		'''
		Lx, Ly = np.shape(self.area_object)
		self.error_frac = 0.
		potential_new = 0.
		potential_old = 0.
		checker = ['red', 'black']
		for colour in checker:
			i = 0
			while i < (Lx-1):
				if colour == 'red':
					if i%2==0:
						j = 0
					else:
						j = 1
				else:
					if i%2==0:
						j = 1
					else:
						j = 0 
				while j < (Ly-1):
					if self.area_object[i][j] == 0:
						potential_prev = self.area_potential[i,j]

						potential_next = self.SOR(w,
						 self.area_potential[i-1,j], self.area_potential[i,j-1],
						  self.area_potential[i,j], self.area_potential[i+1,j],
						   self.area_potential[i,j+1])

						self.area_potential[i,j] = potential_next

						
						potential_new += abs(potential_next)
						potential_old += abs(potential_prev)

						
					j+=2
				i += 1
		self.count+=1
		self.error_frac = abs((potential_new-potential_old)/potential_old)
		
		

	def procedural(self, w = 1.8):
		'''
		An ordering system with by which the method is updated. Goes through
		the system point by point starting from the top left corner of the grid
		w = over relaxation parameter (must be within 1<= w < 2)
		'''
		Lx, Ly = np.shape(self.area_object)
		potential_new = 0.
		potential_old = 0.
		i = 0
		while i < (Lx-1):
			j = 0
			while j < (Ly-1):
				if self.area_object[i][j] == 0:

					potential_prev = self.area_potential[i,j]
					potential_next = self.SOR(w, self.area_potential[i-1,j],
					 self.area_potential[i,j-1], self.area_potential[i,j], 
					 self.area_potential[i+1,j], self.area_potential[i,j+1])
					self.area_potential[i,j] = potential_next

					potential_new += abs(potential_next)
					potential_old += abs(potential_prev)
				j+=1
			i += 1
		self.count+=1
		self.error_frac = abs((potential_new-potential_old)/potential_old)



	def optimal_omega(self):
		'''
		Returns the optimal omega given von Nuemann BCs and a rectangular grid
		based on the shape of the area_object array
		'''
		Lx, Ly = np.shape(self.area_object)
		zeta = ((math.cos(math.pi/(Lx-1)) + math.cos(math.pi/(Ly-1)))/2)**2
		return 2*((1 - math.sqrt(1-zeta))/zeta)

	def chebyshev_acc(self, n):
		Lx, Ly = np.shape(self.area_object)
		p_jacobi = 0.5*(math.cos(math.pi/Ly) + math.cos(math.pi/Lx))
		if n == 0:
			return 1.
		if n == 0.5:
			return 1/(1 - (p_jacobi**2)/2)
		else:
			return self.optimal_omega()

	def counter(self):
		'''
		returns a count of the number of updates the system has run through
		'''
		return self.count

	def error(self):
		'''
		returns the error in the system based on the first degree norm of the system
		'''
		return abs(self.error_frac)

	def convergence(self, tolorence):
		'''
		Decides whether the system has converged or not by conparing the 
		error in the system to the tolerance.
		The tolerance parameter is generally best to range from 1e-4 to 1-14
		'''
		if abs(self.error_frac) < tolorence:
			return True
		else:
			return False

