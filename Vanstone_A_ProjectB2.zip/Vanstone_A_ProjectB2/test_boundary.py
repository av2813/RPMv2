import numpy as np
import lattice_builder_new as lb
import matplotlib.pyplot as plt
import time as tm
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import time as tm
import os
import linecache as lc
import math
from scipy import stats
from variables import *

plt.rc('text', usetex=True)
plt.rc('font', family='serif', size = 22)

#This generates the solutions to the system for a range of different boundaries given
#that the bar width is fixed


target_dir = r"/home/avanstone/Documents/Year_3/Computational_Physics/Project_B/Data/Boundary"
boundary_range = [2.2, 102.]
initial_conditions = "zero"
L_list = []
step_list = []
iterations_list = []
for L in np.linspace(boundary_range[0], boundary_range[1], num = 1):
	tolerance = 0.0001
	L = L+2.
	boundary = [L, L]
	step = 0.005*(L-2)
	K = lb.Shape(step)
	K.boundary(dim = boundary, factor = 1, boundary_pot = 0.)
	K.rectangle(dim = [2., 2.], pos = [L/2., L/2.], potential = potential)
	area_object, area_potential = K.areas()
	A = lb.Pictorial(area_object, area_potential)
	K = lb.Shape(step, area_object, area_potential)
	area_object, area_potential = K.areas()
	A = lb.Pictorial(area_object, area_potential)
	while A.convergence(tolerance) == False:
		omega = A.optimal_omega()
		if ordering == 'redblack':
			A.redblack(method = method, w = omega)
		elif ordering == 'procedural':
			A.procedural(method = method, w = omega)
		else:
			raise Exception("The ordering scheme is not defined correctly")
	L_list.append(L)
	step_list.append(step)
	iterations_list.append(A.counter())
				
	iterations = A.counter()
	heatmap = area_potential
	plt.clf()
	figure1 = plt.imshow(heatmap, aspect = 'auto', extent = (0,boundary[0],0,boundary[1]))
	plt.colorbar()
	testing = method, ordering, tolerance, omega, iterations, step, boundary, potential
	name = "Simple_" + str(step)+"_" +str(omega)+"_" + str(tolerance)+"_" +str(boundary) 
	file_name = os.path.join(target_dir, name + ".txt")
	pic_name = os.path.join(target_dir, name + ".png")
	plt.savefig(pic_name, bbox_inches='tight')
	with open(file_name, "w") as data:
		data.write('Method Ordering Tolerance Omega Iterations Step Boundary Potential\n')
		data.write(str(testing).strip(',')+'\n')
		data.write(str(area_potential.tolist())+'\n')
		data.write(str(area_object.tolist())+'\n')
		data.write(initial_conditions + '\n')
		data.close()

